<?php
$string['auth_amembertitle']='aMember';
$string['auth_amemberdescription']='aMember Authentication Module';
?>