<?php

function get_amember_database_link()
{
    global $CFG;
	
    $dbhost = $CFG->auth_amember_dbhost;
	$dbname = $CFG->auth_amember_dbname;
	$dblogin = $CFG->auth_amember_dblogin;
	$dbpass = $CFG->auth_amember_dbpass;

	if (!$dbhost || !$dbname || !$dblogin) return false;
	$link = @mysql_connect($dbhost, $dblogin, $dbpass);
	if (!$link) return false;
	return $link;
}

function auth_user_login ($username, $password)
{
// Returns true if the username and password work
// and false if they are wrong or don't exist.

	global $CFG;
	$dbname = $CFG->auth_amember_dbname;

	$link = get_amember_database_link();

	if (!$link) return false;
	$login = @mysql_escape_string($username);
	$pass = @mysql_escape_string($password);
	
	$res_p = @mysql_query($s = "SELECT * FROM {$dbname}products", $link);
	if (!$res_p) return false;
	$mooodle_products = array();

	while ($product = @mysql_fetch_assoc($res_p))
	{
	
		$product['data'] = unserialize($product['data']);
		if ($product['data']['moodle_access'])
		{
			if (is_array($product['data']['moodle_access']))
			{
				$mooodle_products = array_unique(array_merge($mooodle_products,$product['data']['moodle_access']));
			} elseif (!in_array($product['data']['moodle_access'],$mooodle_products)) {
				$mooodle_products[] = $product['data']['moodle_access'];
			}
		}
	}
	if (!$mooodle_products) return false;
	
	$res_u = @mysql_query($s = "SELECT * FROM {$dbname}members WHERE login='$login' AND pass='$pass'", $link);
	$res_u = @mysql_fetch_assoc($res_u);
	if (!$res_u) return false;
	$res_payments = @mysql_query($s = "SELECT COUNT(payment_id) FROM {$dbname}payments WHERE product_id IN ('".implode("','",$mooodle_products)."') AND expire_date > '".date('Y-m-d')."' AND completed=1", $link);
	$res_payments = @mysql_fetch_assoc($res_payments);
	if (!$res_payments) return false;
	return true;
}



if (is_file($CFG->dirroot.'/version.php'))
{
	require_once($CFG->dirroot.'/version.php');
	if (substr($release,0,3) == '1.7')
	{
		function auth_user_update($userold, $usernew)
		{
			global $CFG;		
			$link = get_amember_database_link();
			if (!$link) return false;
			$dbname = $CFG->auth_amember_dbname;
			
			$login = @mysql_escape_string($userold->username);
			$name_f = @mysql_escape_string($usernew->firstname);
			$name_l = @mysql_escape_string($usernew->lastname);
			$email = @mysql_escape_string($usernew->email);
			$city = @mysql_escape_string($usernew->city);
			$country = @mysql_escape_string($usernew->country);
			if ($usernew->newpassword) $pass = "pass='".@mysql_escape_string($usernew->newpassword)."',";
			return @mysql_query($s = "UPDATE {$dbname}members SET
								$pass
								name_f='$name_f',
								name_l='$name_l',
								email='$email',
								city='$city',
								country='$country'
							   WHERE login='$login'", $link);
		}
	} elseif (substr($release,0,3) == '1.8') {
		// 1.8 using new class
	}
}

?>
