<?php

if (!defined('MOODLE_INTERNAL')) {
    die('Direct access to this script is forbidden.');    ///  It must be included from a Moodle page
}

require_once($CFG->libdir.'/authlib.php');


/**
 * aMember authentication plugin.
 */
class auth_plugin_amember extends auth_plugin_base {
    var $config;
	var $authtype;

    function auth_plugin_amember() {
		$this->authtype = 'amember';
        $this->config = get_config();
    }
	
	function get_amember_database_link()
	{
	    global $CFG;
		
	    $dbhost = $CFG->auth_amember_dbhost;
		$dbname = $CFG->auth_amember_dbname;
		$dblogin = $CFG->auth_amember_dblogin;
		$dbpass = $CFG->auth_amember_dbpass;

		if (!$dbhost || !$dbname || !$dblogin) return false;
		$link = @mysql_connect($dbhost, $dblogin, $dbpass);
		if (!$link) return false;
		return $link;
	}
	
    function user_login($username, $password)
	{
		global $CFG;
		
		$dbname = $CFG->auth_amember_dbname;
		$link = $this->get_amember_database_link();
		if (!$link) return false;
			
		$login = @mysql_escape_string($username);
		$pass = @mysql_escape_string($password);
		
		$res_p = @mysql_query($s = "SELECT * FROM {$dbname}products", $link);
		if (!$res_p) return false;
		
		$mooodle_products = array();

		while ($product = @mysql_fetch_assoc($res_p))
		{
		
			$product['data'] = unserialize($product['data']);
			if ($product['data']['moodle_access'])
			{
				if (is_array($product['data']['moodle_access']))
				{
					$mooodle_products = array_unique(array_merge($mooodle_products,$product['data']['moodle_access']));
				} elseif (!in_array($product['data']['moodle_access'],$mooodle_products)) {
					$mooodle_products[] = $product['data']['moodle_access'];
				}
			}
		}
		if (!$mooodle_products) return false;
		
		$res_u = @mysql_query($s = "SELECT * FROM {$dbname}members WHERE login='$login' AND pass='$pass'", $link);
		$res_u = @mysql_fetch_assoc($res_u);		
		if (!$res_u) return false;

		$res_payments = @mysql_query($s = "SELECT COUNT(payment_id) FROM {$dbname}payments WHERE product_id IN ('".implode("','",$mooodle_products)."') AND expire_date > '".date('Y-m-d')."' AND completed=1", $link);
		$res_payments = @mysql_fetch_assoc($res_payments);
		if (!$res_payments) return false;
		
		return true;
    }

    function user_update_password($user, $newpassword)
	{
		global $CFG;
		
		$dbname = $CFG->auth_amember_dbname;
		$link = $this->get_amember_database_link();
		if (!$link) return AUTH_CONFIRM_FAIL;
		
		$user = get_complete_user_data('id', $user->id);
		$login = @mysql_escape_string($user->username);
		$pass = @mysql_escape_string($newpassword);
		
		if (@mysql_query($s = "UPDATE {$dbname}members SET pass='$pass' WHERE login='$login'", $link))
			return update_internal_user_password($user, $newpassword);
		return false;
    }
	
	function user_update($userold, $usernew)
	{
		global $CFG;		
		$link = $this->get_amember_database_link();
		if (!$link) return false;
		$dbname = $CFG->auth_amember_dbname;
		
		$login = @mysql_escape_string($userold->username);
		$name_f = @mysql_escape_string($usernew->firstname);
		$name_l = @mysql_escape_string($usernew->lastname);
		$email = @mysql_escape_string($usernew->email);
		$city = @mysql_escape_string($usernew->city);
		$country = @mysql_escape_string($usernew->country);
		if ($usernew->newpassword) $pass = "pass='".@mysql_escape_string($usernew->newpassword)."',";
		return @mysql_query($s = "UPDATE {$dbname}members SET
							$pass
							name_f='$name_f',
							name_l='$name_l',
							email='$email',
							city='$city',
							country='$country'
						   WHERE login='$login'", $link);
	}
	
    function is_internal()
	{
        return true;
    }

    function can_change_password()
	{
        return true;
    }
	
	function change_password_url()
	{
		global $CFG;

		if (class_exists('login_forgot_password_form'))	
		{
			$mform = new login_forgot_password_form();
		} else {
			$dbname = $CFG->auth_amember_dbname;
			$link = $this->get_amember_database_link();
			if (!$link) return '';
			$res_p = @mysql_query($s = "SELECT value FROM {$dbname}config WHERE name = 'root_url'", $link);
			$root_url = @mysql_fetch_assoc($res_p);
			if (!$root_url) return '';
			$root_url = $root_url['value'];
			return $root_url."/profile.php";
		}
		
		if ($mform->is_cancelled())
		{
		    redirect($CFG->httpswwwroot.'/login/index.php');
		} else if ($data = $mform->get_data()) {
			if (!empty($data->username))
			{
				$user = get_complete_user_data('username', $data->username);
				$user_restore_by = $data->username;
		    } else {
		        $user = get_complete_user_data('email', $data->email);
				$user_restore_by = $data->email;
		    }
		    if ($user and !empty($user->confirmed))
			{
				$dbname = $CFG->auth_amember_dbname;
				$link = $this->get_amember_database_link();
				if (!$link) return '';
				
				$res_p = @mysql_query($s = "SELECT value FROM {$dbname}config WHERE name = 'root_url'", $link);
				$root_url = @mysql_fetch_assoc($res_p);
				if (!$root_url) return '';
				$root_url = $root_url['value'];
				redirect($root_url."/sendpass.php?login=".$user_restore_by);
				exit;
			} else {
				return '';
			}
		}
		return '';
    }
	
    function config_form($config, $err, $user_fields)
	{
        include "config18.html";
    }
	
    function process_config($config)
	{
        return true;
    }
}

?>