<?php
/**
* @version $Id: geshi.php 2970 2006-03-30 08:01:32Z stingrey $
* @package Joomla
* @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

$_MAMBOTS->registerFunction( 'onStart', 'amemberStart' );

/**
* Code Highlighting Mambot
*
* Replaces <pre>...</pre> tags with highlighted text
*/
function amemberStart (  ) {
    $amemberRoot = "/amember";

    if (@$_POST['op2'] == 'logout'){
        $return = @$_REQUEST['return'];
        if (!$return) 
            $return = $_SERVER['PHP_SELF'];
        $return = preg_replace('/[\n\r]/', ' ', $return);
        $url = "$amemberRoot/logout.php?amember_redirect_url=$return";
        header("Location: $url");
        exit();
    }

    if (@$_REQUEST['option'] == 'com_registration' || 
         strstr($_SERVER['REQUEST_URI'],'/option,com_registration/')){
        if (@in_array(@$_REQUEST['task'], array('lostPassword', 'sendNewPassword'))
           || strstr($_SERVER['REQUEST_URI'],'lostPassword') || 
              strstr($_SERVER['REQUEST_URI'],'sendNewPassword')){
            header("Location: $amemberRoot/login.php?amember_redirect_url=".$_SERVER['PHP_SELF']);
            exit();
        }
        /* Comment the following lines to disable redirects on register */
        if (@in_array(@$_REQUEST['task'], array('register','saveRegistration','activate')) ||
            strstr($_SERVER['REQUEST_URI'],'register') ||
            strstr($_SERVER['REQUEST_URI'],'saveRegistration') ||
            strstr($_SERVER['REQUEST_URI'],'activate')){
            header("Location: $amemberRoot/signup.php");
            exit();
        }
    }
    if (@$_REQUEST['option'] == 'com_user'){
        if (@in_array(@$_REQUEST['task'], array('UserDetails', 'saveUserEdit'))
            || strstr($_SERVER['REQUEST_URI'],'UserDetails') ||
               strstr($_SERVER['REQUEST_URI'],'saveUserEdit')){
            header("Location: $amemberRoot/profile.php");
            exit();
        }
    }
}
?>