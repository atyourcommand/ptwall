<?php
/**
* @version		$Id: legacy.php 9115 2007-10-03 00:14:30Z jinx $
* @package		Joomla
* @copyright	Copyright (C) 2005 - 2007 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.event.plugin');

class plgSystemaMember extends JPlugin
{
	function plgSystemaMember(& $subject, $config)
	{
		parent::__construct($subject, $config);
	}
	
	function onAfterInitialise()
	{
		global $mainframe;
		
		$plugin =& JPluginHelper::getPlugin('system', 'amember');
		$pluginParams = new JParameter( $plugin->params );
		$amemberRoot = $pluginParams->get( 'amemberroot', '/amember' );
		
		if ($amemberRoot)
		{
			if (substr($amemberRoot,-1) == '/')
			$amemberRoot = strlen($amemberRoot) == 1 ? '/' : substr($amemberRoot, 0, -1);
		} else {
			$amemberRoot = '/amember';
		}
		
		$option = JRequest::getCmd('option');
		$task = JRequest::getCmd('task');
		$view = JRequest::getCmd('view');
		$return = JRequest::getCmd('return');
		$return = base64_decode($return);
		
		if (strstr($_SERVER['REQUEST_URI'],'/logout') || @$task == 'logout')
		{
			if (!$return) 
				$return = $_SERVER['PHP_SELF'];
			$return = preg_replace('/[\n\r]/', ' ', $return);
			$url = "$amemberRoot/logout.php?amember_redirect_url=$return";
			header("Location: $url");
			exit();		
		}
		
		if (strstr($_SERVER['REQUEST_URI'],'/component/user') || @$option == 'com_user')
		{
			if (@in_array(@$task, array('requestreset', 'remindusername')) || strstr($_SERVER['REQUEST_URI'],'/reset') || strstr($_SERVER['REQUEST_URI'],'/remind') || @in_array(@$view, array('reset','remind')))
			{
				header("Location: $amemberRoot/login.php?amember_redirect_url=".$_SERVER['PHP_SELF']);
				exit();		
			}
			if (@in_array(@$task, array('register','register_save','activate')))
			{
				header("Location: $amemberRoot/signup.php");
				exit();	
			}
			if (@in_array(@$view, array('register','register_save','activate')))
			{
				header("Location: $amemberRoot/signup.php");
				exit();	
			}	
		}
		
		if (strstr($_SERVER['REQUEST_URI'],'/your-details') || @$option == 'com_user')
		{
			if (@in_array(@$task, array('save', 'edit')) || strstr($_SERVER['REQUEST_URI'],'/your-details'))
			{
				header("Location: $amemberRoot/profile.php");
				exit();			
			}
		}
	}

}

?>