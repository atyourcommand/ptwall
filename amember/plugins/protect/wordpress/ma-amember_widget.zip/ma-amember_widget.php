<?php
/*
Plugin Name: Membership Academy aMember Widget
Plugin URI: http://www.membershipacademy.com
Description: aMember sidebar widget. Configurable to include aMember Login in your sidebar, and changes login, signup, etc. links to aMember links.
Author: David Moskowitz
Version: 0.1.0
Author URI: http://www.membershipacademy.com

	This is a WordPress plugin (http://wordpress.org).
*/


// We're putting the plugin's functions in one big function we then
// call at 'plugins_loaded' (add_action() at bottom) to ensure the
// required Sidebar Widget functions are available.

function widget_amember_widget_init() {
	// Check to see required Widget API functions are defined...
	if ( !function_exists('register_sidebar_widget') || !function_exists('register_widget_control') )
		return; // ...and if not, exit gracefully from the script.

	// This function prints the sidebar widget--the cool stuff!
	function widget_amember_widget($args) {

 global $amember_widget_signup, $amember_widget_url, $amember_widget_landing;

		// $args is an array of strings which help your widget
		// conform to the active theme: before_widget, before_title,
		// after_widget, and after_title are the array keys.
		extract($args);

		// Collect our widget's options, or define their defaults.
		$options = get_option('widget_amember_widget');


		$amember_widget_url = empty($options['amember_widget_url']) ? '/amember/' : $options['amember_widget_url'];
		$amember_widget_signup = empty($options['amember_widget_signup']) ? 'Sign up today!' : $options['amember_widget_signup'];
		$amember_widget_landing = empty($options['amember_widget_signup']) ? '/amember/signup.php' : $options['amember_widget_landing'];

 global $user_ID, $user_identity;
  get_currentuserinfo();
  if (!$user_ID):
?>
<li id="login" class="login">
     <h2><?php _e('Login'); ?></h2>
<ul> 
    <form name="loginform" id="loginform" action="<?php echo $amember_widget_url; ?>login.php">
<label><?php _e('Login') ?>:<br /><input type="text" name="amember_login" id="log" value="" size="20" tabindex="7" /></label><br />
    <label><?php _e('Password') ?>:<br /> <input type="password" name="amember_pass" id="pwd" value="" size="20" tabindex="8" /></label><br />
    <label><input type="checkbox" name="remember_login" value="1" tabindex="9" /> <?php _e("Remember me"); ?></label><br />
    <input type="submit" name="submit" value="<?php _e('Login'); ?> &raquo;" tabindex="10" />
    <input type="hidden" name="amember_redirect_url" value="<?php echo $_SERVER['REQUEST_URI']; ?>"/>
    </form>
<br>
Not a member yet?<br>
<A HREF="<?php echo $amember_widget_landing; ?>"><?php echo $amember_widget_signup; ?></A>
    </ul></li>
<?php
  else:
?>
<li id="login" class="login">
  <h2><?php echo $user_identity; ?></h2>
    <ul>
<li><a href="<?php echo $amember_widget_url; ?>member.php" class='mainlevel'>Members Page</a></li>
<li><a href="<?php echo $amember_widget_url; ?>profile.php" class='mainlevel'>Edit Profile</a></li>
<li><a href="<?php echo $amember_widget_url; ?>logout.php" class='mainlevel'>Logout</a></li>
    </ul>
</li>
<?php
  endif;
}
 	
	// This is the function that outputs the form to let users edit
	// the widget's title and so on. It's an optional feature, but
	// we'll use it because we can!
	function widget_amember_widget_control() {

		// Collect our widget's options.
//		$options = get_option('widget_amember_widget');
$options = $newoptions = get_option('widget_amember_widget');
		// This is for handing the control form submission.
		if ( $_POST['amember_widget-submit'] ) {
			// Clean up control form submission options
			$newoptions['amember_widget_url'] = strip_tags(stripslashes($_POST['amember_widget_url']));
			$newoptions['amember_widget_signup'] = $_POST['amember_widget_signup'];
			$newoptions['amember_widget_landing'] = $_POST['amember_widget_landing'];

		}

		// If original widget options do not match control form
		// submission options, update them.
		if ( $options != $newoptions ) {
			$options = $newoptions;
			update_option('widget_amember_widget', $options);
		}

		// Format options as valid HTML. Hey, why not.
		$amember_widget_url = htmlspecialchars($options['amember_widget_url'], ENT_QUOTES);
		$amember_widget_signup = htmlspecialchars($options['amember_widget_signup'], ENT_QUOTES);
		$amember_widget_landing = htmlspecialchars($options['amember_widget_landing'], ENT_QUOTES);

// The HTML below is the control form for editing options.
?>
		<div>
		<label for="amember_widget_url" style="line-height:35px;display:block;">aMember URL /amember/ etc: <input type="text" id="amember_widget_url" name="amember_widget_url" value="<?php echo $amember_widget_url; ?>" /></label>
<label for="amember_widget_landing" style="line-height:35px;display:block;">Landing Page URL /wp/?page_id=5 etc:<input type="text" id="amember_widget_landing" name="amember_widget_landing" value="<?php echo $amember_widget_landing; ?>" /></label>
<label for="amember_widget_signup" style="line-height:35px;display:block;">Sign up text: <input type="text" id="amember_widget_signup" name="amember_widget_signup" value="<?php echo $amember_widget_signup; ?>" /></label>
		<input type="hidden" name="amember_widget-submit" id="amember_widget-submit" value="1" />
		</div>
	<?php
	// end of widget_amember_widget_control()
	}

	// This registers the widget. About time.
	register_sidebar_widget('aMember Widget', 'widget_amember_widget');

	// This registers the (optional!) widget control form.
	register_widget_control('aMember Widget', 'widget_amember_widget_control');
}

// Delays plugin execution until Dynamic Sidebar has loaded first.
add_action('plugins_loaded', 'widget_amember_widget_init');

add_filter('the_content', 'replacelinks');
add_filter('comment_text', 'replacelinks');
add_filter('comment_status', 'replacelinks');

function replacelinks($content) {
 global $amember_widget_signup, $amember_widget_url, $amember_widget_landing;


		$options = get_option('widget_amember_widget');


		$amember_widget_url = empty($options['amember_widget_url']) ? '/amember/' : $options['amember_widget_url'];
		$amember_widget_signup = empty($options['amember_widget_signup']) ? 'Sign up today!' : $options['amember_widget_signup'];
		$amember_widget_landing = empty($options['amember_widget_signup']) ? '/amember/signup.php' : $options['amember_widget_landing'];


 $registerurl = get_bloginfo('url').'/wp-login.php?action=register'; 
		$content = str_replace($registerurl, $amember_widget_landing, $content);
 $profileurl = get_bloginfo('url').'/wp-admin/profile.php'; 
		$content = str_replace($profileurl, $amember_widget_url.'profile.php', $content);
 $logouturl = get_bloginfo('url').'/wp-login.php?action=logout'; 
		$content = str_replace($logouturl, $amember_widget_url.'logout.php', $content);
 $loginurl = get_bloginfo('url').'/wp-login.php'; 
		$content = str_replace($loginurl, $amember_widget_url.'login.php', $content);

	return $content;
}



?>