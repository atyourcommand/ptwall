Description
------------------
Update aMember user E-Mail and Password when they changed in My Account -> Edit.

Author
Tacit
-----------------