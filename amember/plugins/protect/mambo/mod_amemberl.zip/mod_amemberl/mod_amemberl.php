<?php
// $Id: mod_amemberl.php,v .01 2004/05/04 22:00 skippybosco Exp $
/**
* Amember Login Module
* @package Mambo Open Source
* @Copyright (C) 2000 - 2003 Miro International Pty Ltd
* @ All rights reserved
* @ Mambo Open Source is Free Software
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @version $Revision: 0.01 $
**/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

if ($my->id) {
	echo _HI; ?><?php echo $my->username;?>
	<br />
	<a href="<?php echo sefRelToAbs("/amember/logout.php"); ?>"><?php echo _BUTTON_LOGOUT; ?></a>
	<br />
	<a href="<?php echo sefRelToAbs("/amember/member.php"); ?>"><?php echo "Edit Profile"; ?></a>
	<?php
} else {
  ?>
	<form action="/amember/login.php" method=post> 
	Username: <input type=text name=amember_login size=10><br> 
	Password: <input type=password name=amember_pass size=10><br> 
	<input type=submit value=Login> 
	</form>
	<a href="<?php echo sefRelToAbs("/amember/signup.php"); ?>"><?php echo "Sign Up Now"; ?></a> 
	<?php
}